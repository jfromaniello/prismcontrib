namespace $safeprojectname$
{
    public interface IShellView
    {
        void ShowView();
    }
}